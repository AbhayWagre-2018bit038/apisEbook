
# Create your views here.
from rest_framework import generics
from .models import Employee
from .serializers import EmployeeSerializer
class EmployeeAPIView(generics.ListAPIView): 
    queryset = Employee.objects.all() 
    serializer_class = EmployeeSerializer
    
class EmployeeAPIDetialView(generics.RetrieveAPIView): 
    queryset = Employee.objects.all() 
    serializer_class = EmployeeSerializer