from django.urls import path
from .views import EmployeeAPIView,EmployeeAPIDetialView
urlpatterns = [ 
    path('<int:pk>/', EmployeeAPIDetialView.as_view()),
    path('', EmployeeAPIView.as_view()), 
]